"use client";

export function SectionHeader1() {
  return (
    <div className="bg-background pt-4 md:pt-6">
      <div className="container mx-auto lg:px-6 px-4 flex flex-col gap-6">
        {/* Main content */}
        <div className="w-full text-muted-foreground p-6 border border-border rounded-md bg-muted text-center border-dashed">
          Replace this div with your content
        </div>
      </div>
    </div>
  );
}